import { z } from "zod";
import { insertScenarioSchema, scenarios } from "./schema";

export const api = {
  scenarios: {
    list: {
      method: "GET" as const,
      path: "/api/scenarios",
      responses: {
        200: z.array(z.custom<typeof scenarios.$inferSelect>()),
      },
    },
    create: {
      method: "POST" as const,
      path: "/api/scenarios",
      input: insertScenarioSchema,
      responses: {
        201: z.custom<typeof scenarios.$inferSelect>(),
        400: z.object({ message: z.string() }),
      },
    },
    delete: {
      method: "DELETE" as const,
      path: "/api/scenarios/:id",
      responses: {
        204: z.void(),
        404: z.object({ message: z.string() }),
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
