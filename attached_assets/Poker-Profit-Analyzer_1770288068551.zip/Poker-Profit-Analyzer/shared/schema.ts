import { pgTable, text, serial, jsonb, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Definitions for the poker table data
export const PLAYER_TYPES = ["Hero", "Reg", "Fish", "Empty"] as const;

// Precision VPIP presets from user table
// VPIP 90-100 uses same stats as 90
function generateVpipPresets() {
  // Base points:
  // 70: rake 22, loss 70
  // 65: rake 20, loss 60
  // Slope for Rake = (22-20)/(70-65) = 2/5 = 0.4
  // Slope for Loss = (70-60)/(70-65) = 10/5 = 2.0
  // Calculation for 60 VPIP:
  // Rake = 20 - (5 * 0.4) = 18
  // Loss = 60 - (5 * 2.0) = 50
  
  const table = [
    { vpip: 60, rake: 18, loss: 45 },
    { vpip: 65, rake: 20, loss: 60 },
    { vpip: 70, rake: 22, loss: 70 },
    { vpip: 75, rake: 26, loss: 100 },
    { vpip: 80, rake: 30, loss: 130 },
    { vpip: 85, rake: 34, loss: 160 },
    { vpip: 90, rake: 41, loss: 200 }
  ];

  const presets = table.map(row => ({
    label: `${row.vpip}%`,
    value: String(row.vpip),
    rake: row.rake,
    loserate: row.loss
  }));

  // Add 95% and 100% as same as 90%
  [95, 100].forEach(v => {
    presets.push({
      label: `${v}%`,
      value: String(v),
      rake: 41,
      loserate: 200
    });
  });

  return presets;
}

export const FISH_VPIP_PRESETS = generateVpipPresets();

export const SEAT_POSITIONS = [0, 1, 2, 3, 4, 5]; // 6-max

export const seatConfigSchema = z.object({
  seatIndex: z.number().min(0).max(5),
  type: z.enum(PLAYER_TYPES),
  fishVpip: z.string().optional(),
  fishRake: z.number().optional(),
  fishLoserate: z.number().optional(),
  isHigh3Bet: z.boolean().optional(),
});

export type SeatConfig = z.infer<typeof seatConfigSchema>;

export const scenarios = pgTable("scenarios", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  seats: jsonb("seats").$type<SeatConfig[]>().notNull(),
  totalEv: real("total_ev").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertScenarioSchema = createInsertSchema(scenarios).pick({
  name: true,
  seats: true,
  totalEv: true,
});

export type Scenario = typeof scenarios.$inferSelect;
export type InsertScenario = z.infer<typeof insertScenarioSchema>;
