import { useState, useMemo } from "react";
import { type SeatConfig, PLAYER_TYPES, FISH_VPIP_PRESETS } from "@shared/schema";
import { PokerTable } from "@/components/PokerTable";
import { SeatDialog } from "@/components/SeatDialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Calculator as CalcIcon, RotateCcw, Settings } from "lucide-react";
import { cn } from "@/lib/utils";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";

const FISH_INDEX = 3;
const CLOCKWISE_INDICES = [3, 4, 5, 0, 1, 2];

const DEFAULT_PRESETS = [
  { value: "60", label: "60% VPIP", rake: 18, loserate: 45 },
  { value: "65", label: "65% VPIP", rake: 20, loserate: 60 },
  { value: "70", label: "70% VPIP", rake: 22, loserate: 70 },
  { value: "75", label: "75% VPIP", rake: 26, loserate: 100 },
  { value: "80", label: "80% VPIP", rake: 30, loserate: 130 },
  { value: "85", label: "85% VPIP", rake: 34, loserate: 160 },
  { value: "90", label: "90% VPIP", rake: 41, loserate: 200 },
];

function getActiveDistanceClockwise(fromIndex: number, toIndex: number, currentSeats: SeatConfig[]): number {
  const fromPos = CLOCKWISE_INDICES.indexOf(fromIndex);
  const toPos = CLOCKWISE_INDICES.indexOf(toIndex);
  if (fromPos === -1 || toPos === -1) return 0;
  
  let activeCount = 0;
  let currPos = fromPos;
  
  while (currPos !== toPos) {
    currPos = (currPos + 1) % 6;
    const seatAtPos = currentSeats.find(s => s.seatIndex === CLOCKWISE_INDICES[currPos]);
    if (seatAtPos && seatAtPos.type !== "Empty") {
      activeCount++;
    }
    if (activeCount > 6) break;
  }
  
  return activeCount;
}

function getPositionCoefficient(distance: number, isHigh3Bet: boolean): number {
  switch (distance) {
    case 1: return 1.5;
    case 2: return 1.1;
    case 3: return 0.9;
    case 4: return 0.8;
    case 5: return isHigh3Bet ? 0.4 : 0.7;
    default: return 0;
  }
}

const initialSeats: SeatConfig[] = Array(6).fill(null).map((_, i) => ({
  seatIndex: i,
  type: i === FISH_INDEX ? "Fish" : i === 0 ? "Hero" : "Reg",
  fishVpip: i === FISH_INDEX ? "90" : undefined,
  fishRake: i === FISH_INDEX ? 41 : undefined,
  fishLoserate: i === FISH_INDEX ? 200 : undefined,
}));

interface CalculationItem {
  fishIndex: number;
  vpip: string;
  loserate: number;
  rake: number;
  realLoserate: number;
  dist: number;
  posCoef: number;
  ev: number;
}

export default function Calculator() {
  const [seats, setSeats] = useState<SeatConfig[]>(initialSeats);
  const [selectedSeatIndex, setSelectedSeatIndex] = useState<number | null>(null);
  const [heroRake, setHeroRake] = useState(11);
  const [fishPresets, setFishPresets] = useState(DEFAULT_PRESETS);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  
  const { toast } = useToast();

  const handleUpdatePreset = (index: number, field: 'rake' | 'loserate', value: number) => {
    setFishPresets(prev => {
      const updated = [...prev];
      updated[index] = { ...updated[index], [field]: value };
      return updated;
    });
  };

  const calculation = useMemo(() => {
    const heroSeat = seats.find(s => s.type === "Hero");
    if (!heroSeat) return { totalEv: 0, breakdowns: {}, nReg: 0, debug: [] as CalculationItem[] };

    const nReg = seats.filter(s => s.type === "Reg" || s.type === "Hero").length;

    let totalEv = 0;
    const breakdowns: Record<number, number> = {};
    const debug: CalculationItem[] = [];

    seats.forEach(seat => {
      if (seat.type === "Fish") {
        const preset = fishPresets.find(p => p.value === seat.fishVpip);
        const loserate = seat.fishVpip === "custom" ? (seat.fishLoserate || 0) : (preset?.loserate || 0);
        const rake = seat.fishVpip === "custom" ? (seat.fishRake || 0) : (preset?.rake || 0);
        
        const dist = getActiveDistanceClockwise(seat.seatIndex, heroSeat.seatIndex, seats);
        const posCoef = getPositionCoefficient(dist, !!seat.isHigh3Bet);
        
        const realLoserate = loserate - rake;
        const evFromThisFish = ((realLoserate / nReg) * posCoef) - heroRake;
        
        totalEv += evFromThisFish;
        breakdowns[seat.seatIndex] = evFromThisFish;
        
        debug.push({
          fishIndex: seat.seatIndex,
          vpip: seat.fishVpip || "90",
          loserate,
          rake,
          realLoserate,
          dist,
          posCoef,
          ev: evFromThisFish
        });
      }
    });

    return { totalEv, breakdowns, nReg, debug };
  }, [seats, heroRake, fishPresets]);

  const handleSeatClick = (index: number) => {
    setSelectedSeatIndex(index);
  };
  
  const handleSeatSave = (newConfig: SeatConfig) => {
    setSeats(prev => {
      let updated = prev.map((s, i) => i === newConfig.seatIndex ? newConfig : s);
      if (newConfig.type === "Hero") {
        updated = updated.map((s, i) => 
          i !== newConfig.seatIndex && s.type === "Hero" ? { ...s, type: "Reg" } : s
        );
      }
      return updated;
    });
  };

  const resetTable = () => {
    setSeats(initialSeats);
    setHeroRake(11);
    setFishPresets(DEFAULT_PRESETS);
    toast({ title: "Reset", description: "Table reset to default state" });
  };

  return (
    <div className="flex h-screen w-full overflow-hidden bg-background">
      <main className="flex-1 flex flex-col h-full overflow-y-auto">
        <header className="h-16 border-b border-border flex items-center justify-between px-6 bg-card/50 backdrop-blur-sm sticky top-0 z-50">
          <div className="flex items-center gap-3">
            <div className="bg-primary/20 p-2 rounded-lg">
              <CalcIcon className="w-5 h-5 text-primary" />
            </div>
            <h1 className="text-xl font-display font-bold text-foreground">Poker EV Calculator</h1>
          </div>
          <div className="flex items-center gap-3">
            <Dialog open={isSettingsOpen} onOpenChange={setIsSettingsOpen}>
              <DialogTrigger asChild>
                <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground">
                  <Settings className="w-4 h-4 mr-2" />
                  Settings
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-xl bg-card border-border max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2 text-xl font-display">
                    <Settings className="w-5 h-5 text-primary" />
                    Global Fish Presets
                  </DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="grid grid-cols-12 gap-4 px-2 text-xs font-bold text-muted-foreground uppercase tracking-wider">
                    <div className="col-span-4">Preset</div>
                    <div className="col-span-4 text-center">Lose Rate</div>
                    <div className="col-span-4 text-center">Rake</div>
                  </div>
                  {fishPresets.map((preset, idx) => (
                    <div key={preset.value} className="grid grid-cols-12 gap-4 items-center bg-secondary/20 p-2 rounded-lg border border-border/50">
                      <div className="col-span-4 font-semibold text-sm">{preset.label}</div>
                      <div className="col-span-4">
                        <Input 
                          type="number" 
                          value={preset.loserate}
                          onChange={(e) => handleUpdatePreset(idx, 'loserate', Number(e.target.value))}
                          className="h-8 text-center bg-background"
                        />
                      </div>
                      <div className="col-span-4">
                        <Input 
                          type="number" 
                          value={preset.rake}
                          onChange={(e) => handleUpdatePreset(idx, 'rake', Number(e.target.value))}
                          className="h-8 text-center bg-background"
                        />
                      </div>
                    </div>
                  ))}
                </div>
                <DialogFooter>
                  <Button onClick={() => setIsSettingsOpen(false)}>Close & Apply</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
            <Button variant="ghost" size="sm" onClick={resetTable} className="text-muted-foreground hover:text-foreground">
              <RotateCcw className="w-4 h-4 mr-2" />
              Reset
            </Button>
          </div>
        </header>

        <div className="flex-1 p-6 md:p-8 max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1 space-y-6">
            <Card className="bg-card border-border shadow-xl">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm uppercase tracking-widest text-muted-foreground font-semibold">
                  Total Expected Value
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-baseline gap-2">
                  <span className={cn(
                    "text-5xl font-mono font-bold tracking-tighter",
                    calculation.totalEv > 0 ? "text-green-400" : calculation.totalEv < 0 ? "text-red-400" : "text-foreground"
                  )}>
                    {calculation.totalEv > 0 ? "+" : ""}{calculation.totalEv.toFixed(2)}
                  </span>
                  <span className="text-xl text-muted-foreground font-medium">bb/100</span>
                </div>
                
                <div className="mt-6 space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Regs + Hero (N-reg)</span>
                    <span className="font-mono text-foreground">{calculation.nReg}</span>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm items-center">
                      <span className="text-muted-foreground">Hero Rake (bb/100)</span>
                      <Input 
                        type="number" 
                        value={heroRake}
                        onChange={(e) => setHeroRake(Number(e.target.value))}
                        className="w-16 h-7 text-xs font-mono text-right bg-secondary/50 border-border/50"
                      />
                    </div>
                  </div>
                </div>

                {calculation.debug.length > 0 && (
                  <div className="mt-8 space-y-6 pt-6 border-t border-border">
                    <div className="text-xs font-bold uppercase tracking-wider text-primary">Calculation Details</div>
                    {calculation.debug.map((item, i) => (
                      <div key={i} className="space-y-2 bg-secondary/20 p-3 rounded-lg border border-border/50">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-xs font-bold text-orange-400">Against Fish (Seat {item.fishIndex + 1})</span>
                          <span className="text-[10px] bg-orange-400/10 text-orange-400 px-1.5 rounded">VPIP {item.vpip}%</span>
                        </div>
                        <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-[11px]">
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Loss - Rake:</span>
                            <span>{item.loserate} - {item.rake} = {item.realLoserate}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Share (N={calculation.nReg}):</span>
                            <span>{(item.realLoserate / calculation.nReg).toFixed(1)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Position Coef:</span>
                            <span className="text-primary font-bold">{item.posCoef}x</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">My Rake:</span>
                            <span className="text-red-400">-{heroRake}</span>
                          </div>
                          <div className="flex justify-between border-t border-white/5 pt-1 mt-1 col-span-2">
                            <span className="text-muted-foreground font-semibold">Fish EV contribution:</span>
                            <span className={cn("font-bold", item.ev > 0 ? "text-green-400" : "text-red-400")}>
                              {item.ev > 0 ? "+" : ""}{item.ev.toFixed(2)}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                    <div className="pt-2 text-[10px] text-muted-foreground italic leading-tight">
                      Final EV = Sum of all Fish EV contributions
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-2 flex flex-col justify-center min-h-[500px]">
            <PokerTable 
              seats={seats} 
              onSeatClick={handleSeatClick}
              evResults={calculation.breakdowns}
              fixedFishIndex={FISH_INDEX}
            />
          </div>
        </div>
      </main>

      {selectedSeatIndex !== null && (
        <SeatDialog
          isOpen={selectedSeatIndex !== null}
          onClose={() => setSelectedSeatIndex(null)}
          seatIndex={selectedSeatIndex}
          config={seats[selectedSeatIndex]}
          onSave={handleSeatSave}
        />
      )}
    </div>
  );
}
