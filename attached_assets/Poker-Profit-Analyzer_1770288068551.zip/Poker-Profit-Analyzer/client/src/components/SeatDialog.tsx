import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import {
  PLAYER_TYPES,
  FISH_VPIP_PRESETS,
  type SeatConfig,
} from "@shared/schema";
import { useState, useEffect } from "react";
import { User, DollarSign, Calculator, Settings } from "lucide-react";
import { cn } from "@/lib/utils";

interface SeatDialogProps {
  isOpen: boolean;
  onClose: () => void;
  seatIndex: number;
  config: SeatConfig;
  onSave: (config: SeatConfig) => void;
}

export function SeatDialog({
  isOpen,
  onClose,
  seatIndex,
  config,
  onSave,
}: SeatDialogProps) {
  const [localConfig, setLocalConfig] = useState<SeatConfig>(config);

  // Reset local state when dialog opens or config changes
  useEffect(() => {
    setLocalConfig(config);
  }, [config, isOpen]);

  const handleTypeChange = (value: string) => {
    const newType = value as typeof PLAYER_TYPES[number];
    setLocalConfig((prev) => ({
      ...prev,
      type: newType,
      // Reset fish stats if changing type away from Fish
      fishVpip: newType === "Fish" ? "90" : undefined,
      fishRake: newType === "Fish" ? (FISH_VPIP_PRESETS.find(p => p.value === "90")?.rake ?? 41) : undefined,
      fishLoserate: newType === "Fish" ? (FISH_VPIP_PRESETS.find(p => p.value === "90")?.loserate ?? 200) : undefined,
      isHigh3Bet: false,
    }));
  };

  const handlePresetChange = (value: string) => {
    if (value === "custom") {
      setLocalConfig((prev) => ({
        ...prev,
        fishVpip: "custom",
      }));
      return;
    }
    const preset = FISH_VPIP_PRESETS.find((p) => p.value === value);
    setLocalConfig((prev) => ({
      ...prev,
      fishVpip: value,
      fishRake: preset?.rake ?? 0,
      fishLoserate: preset?.loserate ?? 0,
    }));
  };

  const handleSave = () => {
    onSave(localConfig);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-md bg-card border-border">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl font-display">
            <Settings className="w-5 h-5 text-primary" />
            Configure Seat {seatIndex + 1}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          <div className="space-y-2">
            <Label className="text-muted-foreground">Player Type</Label>
            <div className="grid grid-cols-2 gap-2">
              {PLAYER_TYPES.map((type) => (
                <div
                  key={type}
                  onClick={() => handleTypeChange(type)}
                  className={cn(
                    "cursor-pointer rounded-lg border p-4 flex items-center justify-center gap-2 transition-all duration-200",
                    localConfig.type === type
                      ? "border-primary bg-primary/10 text-primary ring-2 ring-primary/20"
                      : "border-border hover:border-primary/50 hover:bg-card/50"
                  )}
                >
                  <span className="font-semibold">{type}</span>
                </div>
              ))}
            </div>
          </div>

          {localConfig.type === "Fish" && (
            <div className="space-y-4 animate-in fade-in slide-in-from-top-2 duration-300">
              <div className="space-y-2">
                <Label>VPIP %</Label>
                <Select
                  value={localConfig.fishVpip}
                  onValueChange={handlePresetChange}
                >
                  <SelectTrigger className="bg-background">
                    <SelectValue placeholder="Select VPIP..." />
                  </SelectTrigger>
                  <SelectContent>
                    {FISH_VPIP_PRESETS.map((preset) => (
                      <SelectItem key={preset.value} value={preset.value}>
                        {preset.label}
                      </SelectItem>
                    ))}
                    <SelectItem value="custom">Custom</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-xs uppercase tracking-wider text-muted-foreground">
                    Lose Rate (bb/100)
                  </Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      type="number"
                      value={localConfig.fishLoserate}
                      onChange={(e) =>
                        setLocalConfig((prev) => ({
                          ...prev,
                          fishLoserate: Number(e.target.value),
                        }))
                      }
                      className="pl-9 bg-background"
                      disabled={localConfig.fishVpip !== "custom"}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="text-xs uppercase tracking-wider text-muted-foreground">
                    Rake (bb/100)
                  </Label>
                  <div className="relative">
                    <Calculator className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      type="number"
                      value={localConfig.fishRake}
                      onChange={(e) =>
                        setLocalConfig((prev) => ({
                          ...prev,
                          fishRake: Number(e.target.value),
                        }))
                      }
                      className="pl-9 bg-background"
                      disabled={localConfig.fishVpip !== "custom"}
                    />
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-2 pt-2">
                <Checkbox
                  id="high3bet"
                  checked={localConfig.isHigh3Bet}
                  onCheckedChange={(checked) =>
                    setLocalConfig((prev) => ({
                      ...prev,
                      isHigh3Bet: checked === true,
                    }))
                  }
                />
                <Label
                  htmlFor="high3bet"
                  className="text-sm font-normal leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                >
                  High 3-Bet (&gt;30%)?
                  <span className="block text-xs text-muted-foreground mt-1">
                    Reduces profitability when Fish is in specific positions.
                  </span>
                </Label>
              </div>
            </div>
          )}
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSave} className="bg-primary text-primary-foreground font-semibold">
            Save Configuration
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
