import { type SeatConfig } from "@shared/schema";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

interface PokerTableProps {
  seats: SeatConfig[];
  onSeatClick: (index: number) => void;
  evResults: Record<number, number>;
  fixedFishIndex?: number;
}

/**
 * GTO Wizard Seating Layout (6-Max)
 * Based on the reference image provided:
 * 0: Top Left (CO)
 * 1: Top Right (BTN)
 * 2: Right (SB)
 * 3: Bottom Right (BB) -> We'll use this as our Fixed Fish position
 * 4: Bottom Left (UTG)
 * 5: Left (HJ)
 */
const seatPositions = [
  { top: "12%", left: "32%" },  // 0: Top Left (CO)
  { top: "12%", left: "68%" },  // 1: Top Right (BTN)
  { top: "50%", left: "92%" },  // 2: Right (SB)
  { top: "82%", left: "68%" },  // 3: Bottom Right (Fixed Fish)
  { top: "82%", left: "32%" },  // 4: Bottom Left
  { top: "50%", left: "8%" },   // 5: Left (HJ)
];

const posLabels: Record<number, string> = {
  1: "1.5x",
  2: "1.1x",
  3: "0.9x",
  4: "0.8x",
  5: "0.7x",
};

export function PokerTable({ seats, onSeatClick, evResults, fixedFishIndex }: PokerTableProps) {
  return (
    <div className="relative w-full aspect-[16/10] max-w-2xl mx-auto my-12">
      {/* Table Rim (GTO Wizard Style) */}
      <div className="absolute inset-0 rounded-[120px] border-2 border-gray-700/30 bg-[#1e2022] shadow-[0_0_60px_rgba(0,0,0,0.6)]" />
      
      {/* Inner Felt (Oval Line) */}
      <div className="absolute inset-8 rounded-[100px] border border-gray-700/40 bg-[#252729] flex items-center justify-center">
        <div className="text-gray-700 font-display text-4xl font-bold tracking-[0.2em] opacity-10 select-none uppercase">
          6-MAX
        </div>
      </div>

      {/* Seats */}
      {seats.map((seat, i) => {
        const ev = evResults[i];
        const isFish = seat.type === "Fish";
        const isHero = seat.type === "Hero";
        const isReg = seat.type === "Reg";
        const isEmpty = seat.type === "Empty";

        // Calculate distance from fixed fish (clockwise)
        let distLabel = "";
        if (fixedFishIndex !== undefined && i !== fixedFishIndex) {
          const fromIdx = fixedFishIndex;
          const toIdx = i;
          // Clockwise order matching seatPositions: 3 -> 4 -> 5 -> 0 -> 1 -> 2
          const clockwiseIndices = [3, 4, 5, 0, 1, 2];
          const fromPos = clockwiseIndices.indexOf(fromIdx);
          const toPos = clockwiseIndices.indexOf(toIdx);
          
          let activeDist = 0;
          let currPos = fromPos;
          while (currPos !== toPos) {
            currPos = (currPos + 1) % 6;
            const seatAtPos = seats.find(s => s.seatIndex === clockwiseIndices[currPos]);
            if (seatAtPos && seatAtPos.type !== "Empty") {
              activeDist++;
            }
            if (activeDist > 6) break;
          }
          distLabel = posLabels[activeDist] || "";
        }

        return (
          <motion.button
            key={i}
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            style={{
              position: "absolute",
              top: seatPositions[i].top,
              left: seatPositions[i].left,
              transform: "translate(-50%, -50%)",
            }}
            onClick={() => onSeatClick(i)}
            className={cn(
              "z-10 w-24 h-24 flex flex-col items-center justify-center transition-all duration-300",
              "group focus:outline-none"
            )}
          >
            {/* Seat Circle */}
            <div className={cn(
              "w-16 h-16 rounded-full flex flex-col items-center justify-center border-2 transition-all duration-200 shadow-xl relative",
              isHero ? "bg-[#3cdbb2]/10 border-[#3cdbb2] text-[#3cdbb2]" :
              isFish ? "bg-orange-500/10 border-orange-500 text-orange-500" :
              isReg ? "bg-gray-400/10 border-gray-400 text-gray-400" :
              "bg-[#252729] border-gray-700 text-gray-700 hover:border-gray-500"
            )}>
              {/* Pos Badge (Dist Label) */}
              {distLabel && !isFish && !isEmpty && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-[#1e2022] border border-gray-700 text-[9px] font-bold px-1.5 py-0.5 rounded text-gray-300 z-20">
                  {distLabel}
                </div>
              )}

              <span className="text-[11px] font-bold uppercase tracking-tight">
                {isHero ? "HERO" : isFish ? "FISH" : isReg ? "REG" : "EMPTY"}
              </span>
              
              {isFish && (
                <span className="text-[9px] font-medium opacity-90">{seat.fishVpip}%</span>
              )}
            </div>

            {/* EV Display Below Seat */}
            {ev !== undefined && !isEmpty && !isFish && (
              <div className={cn(
                "mt-2 text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-[#1a1c1e] border border-gray-800 shadow-sm",
                ev > 0 ? "text-[#3cdbb2]" : ev < 0 ? "text-red-400" : "text-gray-500"
              )}>
                {ev > 0 ? "+" : ""}{ev.toFixed(1)}
              </div>
            )}
          </motion.button>
        );
      })}
    </div>
  );
}
