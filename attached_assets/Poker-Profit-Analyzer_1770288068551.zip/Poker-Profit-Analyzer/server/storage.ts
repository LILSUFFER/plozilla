import { type SeatConfig, type Scenario, type InsertScenario } from "@shared/schema";

export interface IStorage {
  // We keep the interface for types but won't use it for much since scenario saving is removed
}

export class MemStorage implements IStorage {
  constructor() {}
}

export const storage = new MemStorage();
