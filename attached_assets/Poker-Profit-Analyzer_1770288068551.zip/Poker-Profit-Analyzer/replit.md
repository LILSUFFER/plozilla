# replit.md

## Overview

This is a poker EV (Expected Value) calculator application for 6-max tables. The app allows users to configure seat positions with different player types (Hero, Reg, Fish, Empty), set fish player parameters (VPIP, rake, loss rate), and calculate expected value based on position coefficients. Users can save and load scenario configurations for future reference.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack Query (React Query) for server state, React useState for local UI state
- **Styling**: Tailwind CSS with CSS variables for theming, shadcn/ui component library (New York style)
- **Animations**: Framer Motion for smooth seat interactions and calculations
- **Build Tool**: Vite with path aliases (@/ for client/src, @shared/ for shared)

### Backend Architecture
- **Framework**: Express 5 on Node.js
- **Language**: TypeScript with ESM modules
- **API Pattern**: REST endpoints defined in shared/routes.ts with Zod validation
- **Database ORM**: Drizzle ORM with PostgreSQL dialect

### Data Flow
1. Frontend components use custom hooks (use-scenarios.ts) that wrap TanStack Query
2. Hooks call REST API endpoints defined in shared/routes.ts
3. Server routes (server/routes.ts) use storage layer (server/storage.ts)
4. Storage layer uses Drizzle ORM to interact with PostgreSQL database

### Shared Code Architecture
- **shared/schema.ts**: Drizzle table definitions and Zod schemas for validation
- **shared/routes.ts**: API route definitions with input/output schemas for type-safe client-server communication

### Key Design Decisions
- **Monorepo structure**: Client, server, and shared code in single repository with path aliases
- **Type-safe API**: Zod schemas shared between client and server ensure consistent validation
- **Component library**: shadcn/ui provides accessible, customizable UI components built on Radix primitives
- **Dark theme**: Professional data-dense dark theme (deep navy/slate) with custom poker role colors

## External Dependencies

### Database
- **PostgreSQL**: Primary database (connection via DATABASE_URL environment variable)
- **Drizzle ORM**: Type-safe database queries and migrations
- **connect-pg-simple**: PostgreSQL session store for Express sessions

### UI Component Primitives
- **Radix UI**: Full suite of accessible component primitives (dialog, select, checkbox, tabs, etc.)
- **Embla Carousel**: Carousel functionality
- **cmdk**: Command menu component
- **vaul**: Drawer component

### Data & Validation
- **Zod**: Schema validation for API inputs/outputs
- **drizzle-zod**: Automatic Zod schema generation from Drizzle tables
- **react-hook-form**: Form handling with @hookform/resolvers for Zod integration

### Utilities
- **TanStack Query**: Server state management and caching
- **date-fns**: Date formatting
- **class-variance-authority**: Component variant management
- **clsx/tailwind-merge**: Conditional class utilities

### Fonts (Google Fonts)
- Outfit (display)
- Inter (body)
- JetBrains Mono (monospace)